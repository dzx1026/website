from django.apps import AppConfig


class FilmspaceConfig(AppConfig):
    name = 'filmspace'
